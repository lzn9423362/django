from django.contrib import admin
from manytomany.models import *
# Register your models here.

admin.site.register(Group)
admin.site.register(User)