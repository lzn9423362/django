from django.contrib import admin
from onetoone.models import *
# Register your models here.
admin.site.register(Person)
admin.site.register(IdCard)