from django.apps import AppConfig


class OnetooneConfig(AppConfig):
    name = 'onetoone'
